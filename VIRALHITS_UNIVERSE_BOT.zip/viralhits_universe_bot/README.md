# VIRALHITS UNIVERSE Discord Bot

Custom Python Discord bot for **VIRALHITS UNIVERSE × ViralHits India × Bhisma Rajput**.

## Included features

- Branded welcome and goodbye messages
- Slash-command help and utility commands
- Staff moderation: warn, warnings, clear, timeout, kick, ban
- Moderation log channel
- Configurable welcome, log and announcement channels
- Branded announcements
- Private support tickets with close button
- Basic anti-flood timeout
- Optional Discord invite-link filter
- XP, levels, rank and leaderboard
- SQLite persistence for settings, warnings, tickets and XP

## Requirements

- Python 3.10+ recommended
- A Discord application/bot created in the Discord Developer Portal
- Bot token stored in `.env` (never publish it)

## 1. Create the Discord application

1. Open https://discord.com/developers/applications
2. Select **New Application** and name it `ViralHits Bot`.
3. Open the **Bot** page and create/reset the bot token.
4. Copy the token into `.env` as `DISCORD_TOKEN`.
5. Under **Privileged Gateway Intents**, enable:
   - **Server Members Intent** — required for join/leave welcome events.
   - **Message Content Intent** — required for message-based anti-flood, invite filtering and XP.
6. Save changes.

The bot does not need Presence Intent.

## 2. Invite the bot

In the Developer Portal:

1. Open **OAuth2 → URL Generator**.
2. Select scopes: `bot` and `applications.commands`.
3. Select only the permissions this bot needs:
   - View Channels
   - Send Messages
   - Embed Links
   - Read Message History
   - Manage Messages (for `/clear` and invite filtering)
   - Moderate Members (for `/timeout` and anti-flood timeout)
   - Kick Members (for `/kick`)
   - Ban Members (for `/ban`)
   - Manage Channels (for `/ticket`)
4. Generate the URL, open it, and add the bot to your server.

Do not grant Administrator unless you have a specific reason. Put the bot's role above roles it needs to moderate, but below the Owner/Founder roles.

## 3. Install on Windows

Open PowerShell in this folder:

```powershell
py -3 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
notepad .env
python bot.py
```

If PowerShell blocks activation, run this once in that PowerShell window:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

Then activate the environment again.

## 4. Configure bot channels

After the bot is online, run these commands as a server administrator:

- `/setchannel kind:Welcome and goodbye channel:#welcome`
- `/setchannel kind:Moderation logs channel:#mod-logs`
- `/setchannel kind:Announcements channel:#announcements`

The exact choice labels appear in Discord's slash-command menu.

Set ticket staff roles in `.env` with comma-separated role IDs:

```env
TICKET_STAFF_ROLE_IDS=123456789012345678,234567890123456789
```

To copy a role ID, enable Developer Mode in Discord, right-click the role and choose **Copy Role ID**. Restart the bot after editing `.env`.

## 5. Slash commands

| Command | Who can use it | Purpose |
|---|---|---|
| `/help` | Everyone | Command guide |
| `/ping` | Everyone | Bot latency |
| `/serverinfo` | Everyone | Server information |
| `/userinfo` | Everyone | Member information |
| `/avatar` | Everyone | Show avatar |
| `/rank` | Everyone | XP and level |
| `/leaderboard` | Everyone | Top 10 XP members |
| `/ticket` | Everyone | Open a private support ticket |
| `/setchannel` | Manage Server | Configure welcome/log/announcement channel |
| `/announce` | Manage Server | Publish a branded announcement |
| `/warn` | Moderate Members | Add a warning |
| `/warnings` | Moderate Members | View warning history |
| `/clear` | Manage Messages | Delete 1–100 recent messages |
| `/timeout` | Moderate Members | Timeout a member |
| `/kick` | Kick Members | Kick a member |
| `/ban` | Ban Members | Ban a member |

## 6. Slash command sync

- For development, set `DEV_GUILD_ID` in `.env` to your server ID. Commands sync to that server on startup and usually appear quickly.
- For production, set `DEV_GUILD_ID=0` (or leave it at 0). Commands sync globally; Discord may take time to propagate global commands.

Restart the bot after changing the environment.

## 7. Deploy 24/7

### Option A — VPS (recommended)
1. Use a Linux VPS with Python 3.10+.
2. Upload this project folder.
3. Create a virtual environment and install requirements.
4. Create `.env` on the VPS with the token and settings.
5. Run under `systemd`, Docker, or another process supervisor.
6. Use persistent disk storage for `viralhits.sqlite3`.

Example systemd service (edit paths and Linux username):

```ini
[Unit]
Description=ViralHits Universe Discord Bot
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/opt/viralhits-bot
EnvironmentFile=/opt/viralhits-bot/.env
ExecStart=/opt/viralhits-bot/.venv/bin/python /opt/viralhits-bot/bot.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

Save as `/etc/systemd/system/viralhits-bot.service`, then:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now viralhits-bot
sudo systemctl status viralhits-bot
```

### Option B — Docker

```bash
docker build -t viralhits-bot .
docker run -d --name viralhits-bot --restart unless-stopped \
  --env-file .env \
  -v "$(pwd)/data:/app/data" \
  -e DATABASE_PATH=/app/data/viralhits.sqlite3 \
  viralhits-bot
```

Ensure the mounted data directory exists and is persistent.

## Safety notes

- Never paste your bot token into chat, GitHub, screenshots, or public files.
- If the token leaks, reset it immediately in the Developer Portal.
- Use least-privilege bot permissions; avoid Administrator.
- Discord role hierarchy still applies: the bot cannot moderate members whose highest role is equal to or above its own.
- Configure staff permissions and ticket visibility before opening the server publicly.
- The anti-flood protection is a basic starting point, not a complete anti-raid system. Keep Discord AutoMod enabled and appoint trusted human moderators.
- This bot does not stream music or download audio.
- SQLite is suitable for a single bot process and small/medium deployments. For very high traffic or multiple bot instances, migrate to PostgreSQL and add a dedicated queue/cache layer.

## Troubleshooting

**Bot says DISCORD_TOKEN is missing**
- Copy `.env.example` to `.env` and add the real token.

**Bot starts but welcome messages do not send**
- Enable Server Members Intent in the Developer Portal and in code (already enabled).
- Run `/setchannel` and choose the welcome channel.
- Ensure the bot can view and send messages there.

**XP or anti-flood does not work**
- Enable Message Content Intent in the Developer Portal.
- Ensure the bot can view the channel.

**Slash commands do not appear**
- Invite with both `bot` and `applications.commands` scopes.
- Check the bot console for sync errors.
- Set `DEV_GUILD_ID` to your server ID for development, then restart.

**Ticket creation fails**
- Grant Manage Channels and View Channels to the bot.
- Check category/channel permission overwrites.

## Official references

- Discord Developer Portal: https://discord.com/developers/applications
- discord.py documentation: https://discordpy.readthedocs.io/en/stable/
- Discord Gateway Intents: https://discord.com/developers/docs/events/gateway
