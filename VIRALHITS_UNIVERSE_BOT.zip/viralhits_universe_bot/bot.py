import os
import re
import time
import sqlite3
import logging
from contextlib import contextmanager
from datetime import timedelta
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
DEV_GUILD_ID = int(os.getenv("DEV_GUILD_ID", "0") or 0)
DB_PATH = os.getenv("DATABASE_PATH", "viralhits.sqlite3")
BRAND = "VIRALHITS UNIVERSE"
ACCENT = discord.Colour.from_rgb(39, 191, 255)
MAX_WARNINGS_DISPLAY = 10

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s"
)
log = logging.getLogger("viralhits")


@contextmanager
def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    with db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS warnings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                moderator_id INTEGER NOT NULL,
                reason TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                guild_id INTEGER NOT NULL,
                key TEXT NOT NULL,
                value TEXT NOT NULL,
                PRIMARY KEY (guild_id, key)
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS xp (
                guild_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                points INTEGER NOT NULL DEFAULT 0,
                last_message REAL NOT NULL DEFAULT 0,
                PRIMARY KEY (guild_id, user_id)
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS tickets (
                channel_id INTEGER PRIMARY KEY,
                guild_id INTEGER NOT NULL,
                opener_id INTEGER NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)


def get_setting(guild_id: int, key: str) -> Optional[str]:
    with db() as conn:
        row = conn.execute(
            "SELECT value FROM settings WHERE guild_id=? AND key=?",
            (guild_id, key)
        ).fetchone()
    return row["value"] if row else None


def set_setting(guild_id: int, key: str, value: str):
    with db() as conn:
        conn.execute("""
            INSERT INTO settings(guild_id, key, value) VALUES(?,?,?)
            ON CONFLICT(guild_id, key) DO UPDATE SET value=excluded.value
        """, (guild_id, key, value))


def xp_level(points: int) -> int:
    # Simple progression: level n requires n² * 100 total XP.
    return int((max(points, 0) / 100) ** 0.5)


def make_embed(title: str, description: str = "") -> discord.Embed:
    return discord.Embed(title=title, description=description, colour=ACCENT)


def is_staff(interaction: discord.Interaction) -> bool:
    p = interaction.user.guild_permissions
    return p.manage_messages or p.moderate_members or p.administrator


class TicketCloseView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label="Close ticket",
        style=discord.ButtonStyle.danger,
        emoji="🔒",
        custom_id="viralhits:ticket_close"
    )
    async def close_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        channel = interaction.channel
        if not isinstance(channel, discord.TextChannel):
            return await interaction.response.send_message("This is not a ticket channel.", ephemeral=True)

        with db() as conn:
            row = conn.execute(
                "SELECT opener_id FROM tickets WHERE channel_id=?",
                (channel.id,)
            ).fetchone()

        opener_id = row["opener_id"] if row else None
        member = interaction.user
        allowed = member.guild_permissions.manage_channels or member.guild_permissions.administrator
        if opener_id and member.id == opener_id:
            allowed = True

        if not allowed:
            return await interaction.response.send_message(
                "Only the ticket creator or staff can close this ticket.",
                ephemeral=True
            )

        await interaction.response.send_message("🔒 Ticket closed. This channel will be deleted in 5 seconds.")
        await discord.utils.sleep_until(discord.utils.utcnow() + timedelta(seconds=5))
        with db() as conn:
            conn.execute("DELETE FROM tickets WHERE channel_id=?", (channel.id,))
        try:
            await channel.delete(reason=f"Ticket closed by {member}")
        except discord.Forbidden:
            log.warning("Missing permission to delete ticket channel %s", channel.id)


class ViralHitsBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.guilds = True
        intents.members = True          # Required for join/leave welcome events.
        intents.message_content = True  # Required for XP and message-based anti-spam.
        super().__init__(command_prefix="!", intents=intents)

    async def setup_hook(self):
        init_db()
        self.add_view(TicketCloseView())
        if DEV_GUILD_ID:
            guild = discord.Object(id=DEV_GUILD_ID)
            self.tree.copy_global_to(guild=guild)
            synced = await self.tree.sync(guild=guild)
            log.info("Synced %s slash commands to development guild %s", len(synced), DEV_GUILD_ID)
        else:
            synced = await self.tree.sync()
            log.info("Synced %s global slash commands", len(synced))

    async def on_ready(self):
        log.info("Logged in as %s (ID: %s)", self.user, self.user.id)
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name="ViralHits Universe 💙"
            )
        )


bot = ViralHitsBot()

# In-memory anti-spam tracking. This resets when the process restarts.
recent_messages = {}


async def send_log(guild: discord.Guild, title: str, description: str):
    channel_id = get_setting(guild.id, "log_channel")
    if not channel_id:
        return
    channel = guild.get_channel(int(channel_id))
    if isinstance(channel, discord.TextChannel):
        try:
            await channel.send(embed=make_embed(title, description))
        except discord.Forbidden:
            log.warning("Cannot send to configured log channel in guild %s", guild.id)


@bot.event
async def on_member_join(member: discord.Member):
    channel_id = get_setting(member.guild.id, "welcome_channel")
    if not channel_id:
        return
    channel = member.guild.get_channel(int(channel_id))
    if isinstance(channel, discord.TextChannel):
        embed = make_embed(
            "🌌 Welcome to VIRALHITS UNIVERSE!",
            f"Welcome {member.mention}!\n\n"
            "🎵 ViralHits India  •  🎮 Gaming  •  🎌 Anime  •  🎨 Creators\n\n"
            "Please read the rules, choose your interests and introduce yourself.\n"
            "**One Universe. Infinite Possibilities. 💙**"
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.set_footer(text="Founded by Bhisma Rajput")
        try:
            await channel.send(embed=embed)
        except discord.Forbidden:
            log.warning("Cannot send welcome message in guild %s", member.guild.id)


@bot.event
async def on_member_remove(member: discord.Member):
    channel_id = get_setting(member.guild.id, "welcome_channel")
    if not channel_id:
        return
    channel = member.guild.get_channel(int(channel_id))
    if isinstance(channel, discord.TextChannel):
        try:
            await channel.send(embed=make_embed(
                "A member has left",
                f"**{discord.utils.escape_markdown(member.display_name)}** has left the Universe. Take care! 💙"
            ))
        except discord.Forbidden:
            pass


@bot.event
async def on_message(message: discord.Message):
    if message.author.bot or not message.guild:
        return

    # Basic anti-flood: 6 messages in 7 seconds triggers a short timeout.
    now = time.monotonic()
    bucket = recent_messages.setdefault((message.guild.id, message.author.id), [])
    bucket[:] = [t for t in bucket if now - t < 7]
    bucket.append(now)
    if len(bucket) >= 7 and isinstance(message.author, discord.Member):
        try:
            await message.author.timeout(timedelta(seconds=30), reason="ViralHits anti-spam: message flood")
            await message.channel.send(f"🛡️ {message.author.mention}, please slow down. You have been timed out for 30 seconds.")
            await send_log(message.guild, "Anti-spam timeout", f"Member: {message.author.mention}\nChannel: {message.channel.mention}")
        except (discord.Forbidden, discord.HTTPException):
            pass
        bucket.clear()
        return

    # Optional invite-link filter. Configure with INVITE_FILTER=true.
    if os.getenv("INVITE_FILTER", "false").lower() == "true":
        if "discord.gg/" in message.content.lower() or "discord.com/invite/" in message.content.lower():
            if not message.author.guild_permissions.manage_messages:
                try:
                    await message.delete()
                    await message.channel.send(
                        f"⚠️ {message.author.mention}, Discord invite links are restricted here.",
                        delete_after=6
                    )
                except (discord.Forbidden, discord.HTTPException):
                    pass
                return

    # XP cooldown: award 5-10 XP once per 60 seconds per member.
    with db() as conn:
        row = conn.execute(
            "SELECT points, last_message FROM xp WHERE guild_id=? AND user_id=?",
            (message.guild.id, message.author.id)
        ).fetchone()
        last = row["last_message"] if row else 0
        if now - last >= 60:
            import random
            award = random.randint(5, 10)
            points = (row["points"] if row else 0) + award
            old_level = xp_level(row["points"]) if row else 0
            new_level = xp_level(points)
            conn.execute("""
                INSERT INTO xp(guild_id, user_id, points, last_message) VALUES(?,?,?,?)
                ON CONFLICT(guild_id, user_id)
                DO UPDATE SET points=excluded.points, last_message=excluded.last_message
            """, (message.guild.id, message.author.id, points, now))
            if new_level > old_level:
                try:
                    await message.channel.send(
                        f"🎉 {message.author.mention} reached **Level {new_level}** in {BRAND}! 💙"
                    )
                except discord.Forbidden:
                    pass


@bot.tree.command(name="help", description="Show the ViralHits Universe bot command guide")
async def help_command(interaction: discord.Interaction):
    embed = make_embed("💙 VIRALHITS BOT — COMMANDS", "")
    embed.add_field(name="Community", value="`/ping` `/serverinfo` `/userinfo` `/avatar` `/rank` `/leaderboard`", inline=False)
    embed.add_field(name="Staff", value="`/setchannel` `/announce` `/warn` `/warnings` `/clear` `/timeout` `/kick` `/ban`", inline=False)
    embed.add_field(name="Support", value="`/ticket` — create a private support ticket", inline=False)
    embed.set_footer(text="ViralHits India × Bhisma Rajput")
    await interaction.response.send_message(embed=embed, ephemeral=True)


@bot.tree.command(name="ping", description="Check bot latency")
async def ping(interaction: discord.Interaction):
    await interaction.response.send_message(f"🏓 Pong! `{round(bot.latency * 1000)} ms`", ephemeral=True)


@bot.tree.command(name="serverinfo", description="Show information about this server")
async def serverinfo(interaction: discord.Interaction):
    guild = interaction.guild
    if guild is None:
        return await interaction.response.send_message("Use this command inside a server.", ephemeral=True)
    embed = make_embed(f"🌌 {guild.name}", f"**Owner:** {guild.owner.mention if guild.owner else 'Unavailable'}\n**Members:** {guild.member_count}\n**Created:** <t:{int(guild.created_at.timestamp())}:D>")
    if guild.icon:
        embed.set_thumbnail(url=guild.icon.url)
    await interaction.response.send_message(embed=embed)


@bot.tree.command(name="userinfo", description="Show information about a member")
@app_commands.describe(member="Member to inspect")
async def userinfo(interaction: discord.Interaction, member: Optional[discord.Member] = None):
    member = member or interaction.user
    embed = make_embed(f"👤 {member.display_name}", f"**User:** {member.mention}\n**ID:** `{member.id}`\n**Joined:** <t:{int(member.joined_at.timestamp())}:R>" if member.joined_at else f"**User:** {member.mention}\n**ID:** `{member.id}`")
    embed.set_thumbnail(url=member.display_avatar.url)
    await interaction.response.send_message(embed=embed)


@bot.tree.command(name="avatar", description="Show a member's avatar")
@app_commands.describe(member="Member whose avatar you want to see")
async def avatar(interaction: discord.Interaction, member: Optional[discord.Member] = None):
    member = member or interaction.user
    embed = make_embed(f"{member.display_name}'s avatar")
    embed.set_image(url=member.display_avatar.url)
    await interaction.response.send_message(embed=embed)


@bot.tree.command(name="setchannel", description="Set a bot channel (staff only)")
@app_commands.checks.has_permissions(manage_guild=True)
@app_commands.describe(kind="Which channel setting to update", channel="Channel to use")
@app_commands.choices(kind=[
    app_commands.Choice(name="Welcome and goodbye", value="welcome_channel"),
    app_commands.Choice(name="Moderation logs", value="log_channel"),
    app_commands.Choice(name="Announcements", value="announcement_channel"),
])
async def setchannel(interaction: discord.Interaction, kind: app_commands.Choice[str], channel: discord.TextChannel):
    set_setting(interaction.guild_id, kind.value, str(channel.id))
    await interaction.response.send_message(f"✅ **{kind.name}** channel set to {channel.mention}.", ephemeral=True)


@bot.tree.command(name="announce", description="Post a branded server announcement (staff only)")
@app_commands.checks.has_permissions(manage_guild=True)
@app_commands.describe(title="Announcement title", message="Announcement text", channel="Optional destination channel")
async def announce(interaction: discord.Interaction, title: str, message: str, channel: Optional[discord.TextChannel] = None):
    target = channel
    if target is None:
        channel_id = get_setting(interaction.guild_id, "announcement_channel")
        target = interaction.guild.get_channel(int(channel_id)) if channel_id else interaction.channel
    if not isinstance(target, discord.TextChannel):
        return await interaction.response.send_message("Set an announcement channel with `/setchannel` first.", ephemeral=True)
    embed = make_embed(f"📢 {title}", message)
    embed.set_footer(text="VIRALHITS UNIVERSE • Bhisma Rajput")
    await target.send(embed=embed)
    await interaction.response.send_message(f"✅ Announcement posted in {target.mention}.", ephemeral=True)


@bot.tree.command(name="warn", description="Warn a member (staff only)")
@app_commands.checks.has_permissions(moderate_members=True)
@app_commands.describe(member="Member to warn", reason="Reason for the warning")
async def warn(interaction: discord.Interaction, member: discord.Member, reason: str):
    if member.id == interaction.user.id or member.bot:
        return await interaction.response.send_message("You cannot warn yourself or a bot.", ephemeral=True)
    with db() as conn:
        conn.execute(
            "INSERT INTO warnings(guild_id,user_id,moderator_id,reason) VALUES(?,?,?,?)",
            (interaction.guild_id, member.id, interaction.user.id, reason[:500])
        )
    await interaction.response.send_message(f"⚠️ {member.mention} has been warned. Reason: {reason}", ephemeral=True)
    await send_log(interaction.guild, "Member warned", f"Member: {member.mention}\nModerator: {interaction.user.mention}\nReason: {reason}")


@bot.tree.command(name="warnings", description="View a member's warning history (staff only)")
@app_commands.checks.has_permissions(moderate_members=True)
async def warnings(interaction: discord.Interaction, member: discord.Member):
    with db() as conn:
        rows = conn.execute(
            "SELECT reason, moderator_id, created_at FROM warnings WHERE guild_id=? AND user_id=? ORDER BY id DESC LIMIT ?",
            (interaction.guild_id, member.id, MAX_WARNINGS_DISPLAY)
        ).fetchall()
    if not rows:
        return await interaction.response.send_message(f"✅ {member.mention} has no recorded warnings.", ephemeral=True)
    lines = [f"• **{r['created_at']}** — {r['reason']} (by <@{r['moderator_id']}>)" for r in rows]
    await interaction.response.send_message(
        embed=make_embed(f"⚠️ Warnings for {member}", "\n".join(lines)),
        ephemeral=True
    )


@bot.tree.command(name="clear", description="Delete recent messages (staff only)")
@app_commands.checks.has_permissions(manage_messages=True)
@app_commands.describe(amount="Number of messages to delete (1–100)")
async def clear(interaction: discord.Interaction, amount: app_commands.Range[int, 1, 100]):
    if not isinstance(interaction.channel, discord.TextChannel):
        return await interaction.response.send_message("Use this in a text channel.", ephemeral=True)
    await interaction.response.defer(ephemeral=True)
    deleted = await interaction.channel.purge(limit=amount)
    await interaction.followup.send(f"🧹 Deleted {len(deleted)} messages.", ephemeral=True)
    await send_log(interaction.guild, "Messages cleared", f"{interaction.user.mention} deleted {len(deleted)} messages in {interaction.channel.mention}.")


@bot.tree.command(name="timeout", description="Timeout a member (staff only)")
@app_commands.checks.has_permissions(moderate_members=True)
@app_commands.describe(member="Member to timeout", minutes="Duration in minutes (1–10080)", reason="Reason")
async def timeout_member(interaction: discord.Interaction, member: discord.Member, minutes: app_commands.Range[int, 1, 10080], reason: str = "No reason provided"):
    if member.id == interaction.user.id or member.bot:
        return await interaction.response.send_message("You cannot timeout yourself or a bot.", ephemeral=True)
    await member.timeout(timedelta(minutes=minutes), reason=f"{interaction.user}: {reason}")
    await interaction.response.send_message(f"🔇 {member.mention} timed out for {minutes} minutes.", ephemeral=True)
    await send_log(interaction.guild, "Member timed out", f"Member: {member.mention}\nDuration: {minutes} minutes\nReason: {reason}")


@bot.tree.command(name="kick", description="Kick a member (staff only)")
@app_commands.checks.has_permissions(kick_members=True)
@app_commands.describe(member="Member to kick", reason="Reason")
async def kick_member(interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
    if member.id == interaction.user.id or member.top_role >= interaction.user.top_role:
        return await interaction.response.send_message("You cannot kick yourself or a member with an equal/higher role.", ephemeral=True)
    await member.kick(reason=f"{interaction.user}: {reason}")
    await interaction.response.send_message(f"👢 Kicked **{member}**. Reason: {reason}", ephemeral=True)
    await send_log(interaction.guild, "Member kicked", f"Member: {member}\nModerator: {interaction.user.mention}\nReason: {reason}")


@bot.tree.command(name="ban", description="Ban a member (staff only)")
@app_commands.checks.has_permissions(ban_members=True)
@app_commands.describe(member="Member to ban", reason="Reason")
async def ban_member(interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
    if member.id == interaction.user.id or member.top_role >= interaction.user.top_role:
        return await interaction.response.send_message("You cannot ban yourself or a member with an equal/higher role.", ephemeral=True)
    await member.ban(reason=f"{interaction.user}: {reason}", delete_message_seconds=0)
    await interaction.response.send_message(f"🔨 Banned **{member}**. Reason: {reason}", ephemeral=True)
    await send_log(interaction.guild, "Member banned", f"Member: {member}\nModerator: {interaction.user.mention}\nReason: {reason}")


@bot.tree.command(name="ticket", description="Open a private support ticket")
@app_commands.describe(topic="Briefly describe what you need help with")
async def ticket(interaction: discord.Interaction, topic: str = "General support"):
    guild = interaction.guild
    if guild is None:
        return await interaction.response.send_message("Use this command inside a server.", ephemeral=True)

    existing = None
    with db() as conn:
        row = conn.execute(
            "SELECT channel_id FROM tickets WHERE guild_id=? AND opener_id=?",
            (guild.id, interaction.user.id)
        ).fetchone()
        if row:
            existing = guild.get_channel(row["channel_id"])

    if existing:
        return await interaction.response.send_message(f"You already have an open ticket: {existing.mention}", ephemeral=True)

    category = discord.utils.get(guild.categories, name="🎫 SUPPORT TICKETS")
    if category is None:
        try:
            category = await guild.create_category("🎫 SUPPORT TICKETS", reason="ViralHits ticket system")
        except discord.Forbidden:
            return await interaction.response.send_message("I need Manage Channels permission to create tickets.", ephemeral=True)

    overwrites = {
        guild.default_role: discord.PermissionOverwrite(view_channel=False),
        interaction.user: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True, attach_files=True),
        guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True, manage_channels=True),
    }
    staff_role_ids = os.getenv("TICKET_STAFF_ROLE_IDS", "")
    for raw_id in staff_role_ids.split(","):
        raw_id = raw_id.strip()
        if raw_id.isdigit():
            role = guild.get_role(int(raw_id))
            if role:
                overwrites[role] = discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True)

    safe_name = re.sub(r"[^a-z0-9-]", "-", interaction.user.name.lower())[:18].strip("-") or "member"
    try:
        channel = await guild.create_text_channel(
            name=f"ticket-{safe_name}",
            category=category,
            overwrites=overwrites,
            topic=f"Ticket opener ID: {interaction.user.id} | Topic: {topic[:150]}",
            reason=f"Support ticket opened by {interaction.user}"
        )
    except discord.Forbidden:
        return await interaction.response.send_message("I cannot create the ticket. Check my Manage Channels permission.", ephemeral=True)

    with db() as conn:
        conn.execute(
            "INSERT INTO tickets(channel_id,guild_id,opener_id) VALUES(?,?,?)",
            (channel.id, guild.id, interaction.user.id)
        )

    embed = make_embed("🎫 VIRALHITS SUPPORT", f"Hello {interaction.user.mention}!\n\n**Topic:** {topic}\n\nA team member will help you soon. Do not share passwords or private credentials here.")
    await channel.send(content=interaction.user.mention, embed=embed, view=TicketCloseView())
    await interaction.response.send_message(f"✅ Your private ticket is ready: {channel.mention}", ephemeral=True)


@bot.tree.command(name="rank", description="Check your community XP and level")
@app_commands.describe(member="Member to check")
async def rank(interaction: discord.Interaction, member: Optional[discord.Member] = None):
    member = member or interaction.user
    with db() as conn:
        row = conn.execute(
            "SELECT points FROM xp WHERE guild_id=? AND user_id=?",
            (interaction.guild_id, member.id)
        ).fetchone()
    points = row["points"] if row else 0
    level = xp_level(points)
    next_level_xp = (level + 1) ** 2 * 100
    embed = make_embed(f"💙 {member.display_name}'s Rank", f"**Level:** {level}\n**Total XP:** {points}\n**Next level:** {max(0, next_level_xp - points)} XP to go")
    embed.set_thumbnail(url=member.display_avatar.url)
    await interaction.response.send_message(embed=embed)


@bot.tree.command(name="leaderboard", description="Show the top 10 community members by XP")
async def leaderboard(interaction: discord.Interaction):
    with db() as conn:
        rows = conn.execute(
            "SELECT user_id, points FROM xp WHERE guild_id=? ORDER BY points DESC LIMIT 10",
            (interaction.guild_id,)
        ).fetchall()
    if not rows:
        return await interaction.response.send_message("No XP activity yet. Start chatting to earn XP! 💙")
    lines = []
    for index, row in enumerate(rows, start=1):
        lines.append(f"**{index}.** <@{row['user_id']}> — **{row['points']} XP** (Level {xp_level(row['points'])})")
    await interaction.response.send_message(embed=make_embed("🏆 VIRALHITS LEADERBOARD", "\n".join(lines)))


@bot.tree.error
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.MissingPermissions):
        message = "❌ You do not have permission to use this command."
    elif isinstance(error, app_commands.BotMissingPermissions):
        message = "❌ I am missing a required permission. Ask an administrator to check my role permissions."
    elif isinstance(error, app_commands.CommandOnCooldown):
        message = "⏳ Please wait before using that command again."
    else:
        log.error("Slash command error: %s", error, exc_info=error)
        message = "⚠️ Something went wrong. Check the bot console or ask an administrator."
    try:
        if interaction.response.is_done():
            await interaction.followup.send(message, ephemeral=True)
        else:
            await interaction.response.send_message(message, ephemeral=True)
    except discord.HTTPException:
        pass


if __name__ == "__main__":
    if not BOT_TOKEN:
        raise SystemExit("DISCORD_TOKEN is missing. Copy .env.example to .env and add your bot token.")
    bot.run(BOT_TOKEN, log_handler=None)
